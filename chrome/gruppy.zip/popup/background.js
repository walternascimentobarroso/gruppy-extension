chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "togglePasswordInputs") {
    chrome.scripting.executeScript({
      code: `
        const passwordInputs = document.querySelectorAll('input[type="password"]');
        passwordInputs.forEach((input) => {
          input.type = "text";
        });
      `
    });
  }
});
