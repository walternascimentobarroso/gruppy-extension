"use strict";

function togglePassword(tab) {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      let param = 'input[data-original-type="password"]';
      let passwordInputs = document.querySelectorAll(param);
      if (passwordInputs.length > 0) {
        passwordInputs.forEach((input) => {
          input.type = "password";
          input.removeAttribute("data-original-type");
        });
        return;
      }

      passwordInputs = document.querySelectorAll('input[type="password"]');
      passwordInputs.forEach((input) => {
        input.type = "text";
        input.setAttribute("data-original-type", "password");
      });
    },
  });
}

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  let tab = tabs[0];

  document.addEventListener("DOMContentLoaded", function () {
    const btnTogglePassword = document.getElementById("togglePassword");
    btnTogglePassword.addEventListener("click", () => {
      btnTogglePassword.textContent =
        btnTogglePassword.textContent === "Mostrar Senhas"
          ? "Esconder Senhas"
          : "Mostrar Senhas";

      togglePassword(tab);
    });
  });
});
