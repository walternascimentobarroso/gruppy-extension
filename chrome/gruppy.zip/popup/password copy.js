"use strict";

function togglePassword(tab) {
  console.log("togglePassword");

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      const passwordInputs = document.querySelectorAll(
        'input[type="password"]'
      );
      passwordInputs.forEach((input) => {
        input.type = "text";
        input.setAttribute("data-original-type", "password");
      });
    },
  });
}

function revertPassword(tab) {
  console.log("revertPassword");

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      const passwordInputs = document.querySelectorAll(
        'input[data-original-type="password"]'
      );
      passwordInputs.forEach((input) => {
        input.type = "password";
        input.removeAttribute("data-original-type");
      });
    },
  });
}

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  let tab = tabs[0];

  document.addEventListener("DOMContentLoaded", function () {
    document
      .getElementById("togglePassword")
      .addEventListener("click", () => togglePassword(tab));

    document
      .getElementById("revertPassword")
      .addEventListener("click", () => revertPassword(tab));
  });
});
